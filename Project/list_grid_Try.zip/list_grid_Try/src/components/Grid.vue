<template>
  <div class="gridview">
    <h1>Grid View</h1>
    <h2>
      <slot></slot>
    </h2>
  </div>
</template>

<style>
.gridview h1 {
  text-align: center;
}
</style>
